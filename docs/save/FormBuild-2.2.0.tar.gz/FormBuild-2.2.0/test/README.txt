Tests
=====

Run this command to test the helpers using doctest::

    python formbuild/helpers.py



